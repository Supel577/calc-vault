package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_files")
data class VaultFile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val originalName: String,
    val fileUri: String, // Absolute file path in the app's internal secure storage
    val originalPath: String?, // Original name or Uri for unhiding references
    val mediaType: String, // "PHOTO" or "VIDEO"
    val addedTimestamp: Long = System.currentTimeMillis()
)
