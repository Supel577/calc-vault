package com.example.data

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class VaultRepository(private val context: Context, private val dao: VaultFileDao) {

    fun getPhotos(): Flow<List<VaultFile>> = dao.getFilesByType("PHOTO")
    fun getVideos(): Flow<List<VaultFile>> = dao.getFilesByType("VIDEO")
    fun getAllFiles(): Flow<List<VaultFile>> = dao.getAllFiles()

    suspend fun importMedia(uri: Uri, mediaType: String): Boolean = withContext(Dispatchers.IO) {
        val vaultFile = copyUriToPrivateStorage(uri, mediaType) ?: return@withContext false
        dao.insertFile(vaultFile) > 0
    }

    suspend fun deleteFile(vaultFile: VaultFile) = withContext(Dispatchers.IO) {
        // Delete physical file
        val file = File(vaultFile.fileUri)
        if (file.exists()) {
            file.delete()
        }
        // Delete database entry
        dao.deleteFile(vaultFile)
    }

    suspend fun unhideFile(vaultFile: VaultFile): Boolean = withContext(Dispatchers.IO) {
        val restored = unhideFileToPublic(vaultFile)
        if (restored) {
            // Delete physical secure copy
            val file = File(vaultFile.fileUri)
            if (file.exists()) {
                file.delete()
            }
            // Delete database entry
            dao.deleteFile(vaultFile)
            true
        } else {
            false
        }
    }

    private fun copyUriToPrivateStorage(uri: Uri, mediaType: String): VaultFile? {
        val contentResolver = context.contentResolver
        var originalName = "vault_${System.currentTimeMillis()}"
        
        // Find display name
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    originalName = cursor.getString(nameIndex)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val subFolder = if (mediaType == "PHOTO") "vault_photos" else "vault_videos"
        val directory = File(context.filesDir, subFolder)
        if (!directory.exists()) {
            directory.mkdirs()
        }

        val mimeType = contentResolver.getType(uri)
        val extension = if (mimeType != null) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) ?: ""
        } else {
            MimeTypeMap.getFileExtensionFromUrl(uri.toString())
        }
        
        val extSuffix = if (extension.isNotEmpty()) ".$extension" else ""
        val uniqueFileName = "hidden_${System.currentTimeMillis()}_${(100..999).random()}$extSuffix"
        val targetFile = File(directory, uniqueFileName)

        return try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            VaultFile(
                fileName = uniqueFileName,
                originalName = originalName,
                fileUri = targetFile.absolutePath,
                originalPath = uri.toString(),
                mediaType = mediaType
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun unhideFileToPublic(vaultFile: VaultFile): Boolean {
        val file = File(vaultFile.fileUri)
        if (!file.exists()) return false

        val resolver = context.contentResolver
        val mediaType = vaultFile.mediaType
        val name = vaultFile.originalName

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, if (mediaType == "PHOTO") "image/*" else "video/*")
                    val relativePath = if (mediaType == "PHOTO") "Pictures/CalculatorVault" else "Movies/CalculatorVault"
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
                val collectionUri = if (mediaType == "PHOTO") {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }
                val newUri = resolver.insert(collectionUri, contentValues)
                if (newUri != null) {
                    resolver.openOutputStream(newUri)?.use { out ->
                        FileInputStream(file).use { input ->
                            input.copyTo(out)
                        }
                    }
                    true
                } else {
                    false
                }
            } else {
                // Pre-Q Android legacy save to shared directory
                val publicDir = if (mediaType == "PHOTO") {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                } else {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                }
                val targetFolder = File(publicDir, "CalculatorVault")
                if (!targetFolder.exists()) {
                    targetFolder.mkdirs()
                }
                val targetFile = File(targetFolder, name)
                FileInputStream(file).use { input ->
                    FileOutputStream(targetFile).use { out ->
                        input.copyTo(out)
                    }
                }
                // Trigger Media Scanner so it registers in system gallery
                MediaScannerConnection.scanFile(context, arrayOf(targetFile.absolutePath), null, null)
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
