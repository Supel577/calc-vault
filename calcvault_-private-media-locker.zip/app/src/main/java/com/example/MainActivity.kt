package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.CalculatorScreen
import com.example.ui.CalculatorViewModel
import com.example.ui.VaultScreen
import com.example.ui.VaultViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val calculatorViewModel: CalculatorViewModel = viewModel()
                val vaultViewModel: VaultViewModel = viewModel()
                val isUnlocked by calculatorViewModel.isVaultUnlocked.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    if (isUnlocked) {
                        VaultScreen(
                            vaultViewModel = vaultViewModel,
                            onLockClicked = { calculatorViewModel.lockVault() },
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        CalculatorScreen(
                            viewModel = calculatorViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
