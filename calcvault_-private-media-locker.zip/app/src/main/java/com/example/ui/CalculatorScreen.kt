package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val display by viewModel.display.collectAsState()
    val instruction by viewModel.instruction.collectAsState()
    val pinState by viewModel.pinState.collectAsState()

    // Slate theme colors
    val backgroundColor = Color(0xFF1C1C1E)
    val displayTextColor = Color.White
    val numberButtonBg = Color(0xFF2C2C2E)
    val numberButtonText = Color.White
    val actionButtonBg = Color(0xFFD4D4D2)
    val actionButtonText = Color.Black
    val operatorButtonBg = Color(0xFFFF9500)
    val operatorButtonText = Color.White

    Surface(
        modifier = modifier.fillMaxSize(),
        color = backgroundColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header / App Branding or Pin Setup Instructions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Calculator",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.Gray,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.5.sp
                )

                // Only show instructions if PIN setup is incomplete or actively being set
                if (pinState == PinState.NOT_SET || pinState == PinState.SET_STEP_2) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = instruction,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                shape = CircleShape
                            )
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }

            // Calculation Display area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = 16.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = display,
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = if (display.length > 8) 48.sp else 64.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.Default
                    ),
                    color = displayTextColor,
                    textAlign = TextAlign.End,
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .testTag("calculator_display")
                )
            }

            // Keypad layout
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Row 1: C, %, ÷
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CalculatorButton(
                        text = "C",
                        backgroundColor = actionButtonBg,
                        textColor = actionButtonText,
                        modifier = Modifier.weight(2f),
                        onClick = { viewModel.onInput("C") }
                    )
                    CalculatorButton(
                        text = "%",
                        backgroundColor = actionButtonBg,
                        textColor = actionButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("%") }
                    )
                    CalculatorButton(
                        text = "÷",
                        backgroundColor = operatorButtonBg,
                        textColor = operatorButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("÷") }
                    )
                }

                // Row 2: 7, 8, 9, ×
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CalculatorButton(
                        text = "7",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("7") }
                    )
                    CalculatorButton(
                        text = "8",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("8") }
                    )
                    CalculatorButton(
                        text = "9",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("9") }
                    )
                    CalculatorButton(
                        text = "×",
                        backgroundColor = operatorButtonBg,
                        textColor = operatorButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("×") }
                    )
                }

                // Row 3: 4, 5, 6, -
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CalculatorButton(
                        text = "4",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("4") }
                    )
                    CalculatorButton(
                        text = "5",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("5") }
                    )
                    CalculatorButton(
                        text = "6",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("6") }
                    )
                    CalculatorButton(
                        text = "-",
                        backgroundColor = operatorButtonBg,
                        textColor = operatorButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("-") }
                    )
                }

                // Row 4: 1, 2, 3, +
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CalculatorButton(
                        text = "1",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("1") }
                    )
                    CalculatorButton(
                        text = "2",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("2") }
                    )
                    CalculatorButton(
                        text = "3",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("3") }
                    )
                    CalculatorButton(
                        text = "+",
                        backgroundColor = operatorButtonBg,
                        textColor = operatorButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("+") }
                    )
                }

                // Row 5: 0, ., =
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CalculatorButton(
                        text = "0",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(2f),
                        onClick = { viewModel.onInput("0") }
                    )
                    CalculatorButton(
                        text = ".",
                        backgroundColor = numberButtonBg,
                        textColor = numberButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput(".") }
                    )
                    CalculatorButton(
                        text = "=",
                        backgroundColor = operatorButtonBg,
                        textColor = operatorButtonText,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onInput("=") }
                    )
                }
            }
        }
    }
}

@Composable
fun CalculatorButton(
    text: String,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .aspectRatio(if (text == "0" || text == "C") 2f else 1f)
            .clip(CircleShape)
            .background(backgroundColor)
            .clickable { onClick() }
            .testTag("btn_$text"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium
            ),
            color = textColor
        )
    }
}
