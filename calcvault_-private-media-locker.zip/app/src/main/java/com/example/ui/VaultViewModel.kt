package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.VaultDatabase
import com.example.data.VaultFile
import com.example.data.VaultRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VaultViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VaultRepository

    init {
        val database = VaultDatabase.getDatabase(application)
        repository = VaultRepository(application, database.vaultFileDao())
    }

    val photos: StateFlow<List<VaultFile>> = repository.getPhotos()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val videos: StateFlow<List<VaultFile>> = repository.getVideos()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _messageFlow = MutableSharedFlow<String>()
    val messageFlow: SharedFlow<String> = _messageFlow.asSharedFlow()

    fun importMedia(uri: Uri, isVideo: Boolean) {
        viewModelScope.launch {
            _isLoading.value = true
            val success = repository.importMedia(uri, if (isVideo) "VIDEO" else "PHOTO")
            _isLoading.value = false
            if (success) {
                _messageFlow.emit("Successfully imported to secure vault!")
            } else {
                _messageFlow.emit("Failed to import file.")
            }
        }
    }

    fun unhideFile(vaultFile: VaultFile) {
        viewModelScope.launch {
            _isLoading.value = true
            val success = repository.unhideFile(vaultFile)
            _isLoading.value = false
            if (success) {
                _messageFlow.emit("Successfully restored to public gallery!")
            } else {
                _messageFlow.emit("Failed to restore file.")
            }
        }
    }

    fun deleteFile(vaultFile: VaultFile) {
        viewModelScope.launch {
            _isLoading.value = true
            repository.deleteFile(vaultFile)
            _isLoading.value = false
            _messageFlow.emit("File permanently deleted.")
        }
    }
}
