package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.DecimalFormat

enum class PinState {
    NOT_SET,     // No PIN configured
    SET_STEP_1,  // Entered first 4 digits, waiting for '='
    SET_STEP_2,  // Confirming 4 digits, waiting for '='
    READY        // PIN configured, standard operations
}

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("calculator_vault_prefs", Context.MODE_PRIVATE)

    private val _display = MutableStateFlow("0")
    val display: StateFlow<String> = _display.asStateFlow()

    private val _instruction = MutableStateFlow("")
    val instruction: StateFlow<String> = _instruction.asStateFlow()

    private val _pinState = MutableStateFlow(PinState.READY)
    val pinState: StateFlow<PinState> = _pinState.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private var firstAttemptPin = ""
    private var isNewCalculation = true

    init {
        checkPinStatus()
    }

    fun checkPinStatus() {
        val hasPin = sharedPrefs.getBoolean("PIN_SET", false)
        if (!hasPin) {
            _pinState.value = PinState.NOT_SET
            _instruction.value = "Set 4-Digit PIN & Press ="
        } else {
            _pinState.value = PinState.READY
            _instruction.value = "Enter PIN & Press ="
        }
        _display.value = "0"
        _isVaultUnlocked.value = false
        isNewCalculation = true
    }

    fun onInput(char: String) {
        val current = _display.value

        when (char) {
            "C" -> {
                _display.value = "0"
                isNewCalculation = true
            }
            "=" -> {
                handleEquals()
            }
            "%" -> {
                if (current != "0" && !isOperator(current.last())) {
                    _display.value = "$current%"
                }
            }
            ".", "+", "-", "×", "÷" -> {
                isNewCalculation = false
                if (isOperator(char.first())) {
                    if (current.isNotEmpty() && isOperator(current.last())) {
                        // Replace last operator
                        _display.value = current.dropLast(1) + char
                    } else {
                        _display.value = current + char
                    }
                } else {
                    // Decimal point
                    val parts = current.split("+", "-", "×", "÷")
                    val lastPart = parts.lastOrNull() ?: ""
                    if (!lastPart.contains(".")) {
                        _display.value = current + char
                    }
                }
            }
            else -> { // Digits 0-9
                if (current == "0" || isNewCalculation) {
                    _display.value = char
                    isNewCalculation = false
                } else {
                    _display.value = current + char
                }
            }
        }
    }

    private fun handleEquals() {
        val expr = _display.value
        val state = _pinState.value

        // Check if expression is exactly 4 digits (e.g. valid PIN entry format)
        val isFourDigits = expr.length == 4 && expr.all { it.isDigit() }

        if (state == PinState.NOT_SET) {
            if (isFourDigits) {
                firstAttemptPin = expr
                _pinState.value = PinState.SET_STEP_2
                _instruction.value = "Confirm PIN & Press ="
                _display.value = "0"
                isNewCalculation = true
            } else {
                _instruction.value = "PIN must be exactly 4 digits!"
                _display.value = "0"
                isNewCalculation = true
            }
            return
        }

        if (state == PinState.SET_STEP_2) {
            if (isFourDigits) {
                if (expr == firstAttemptPin) {
                    // Success! Store PIN
                    sharedPrefs.edit()
                        .putString("PIN_CODE", expr)
                        .putBoolean("PIN_SET", true)
                        .apply()
                    _pinState.value = PinState.READY
                    _instruction.value = "PIN Saved! Enter PIN to Unlock"
                    _display.value = "0"
                    isNewCalculation = true
                } else {
                    _pinState.value = PinState.NOT_SET
                    _instruction.value = "Mismatch! Set 4-digit PIN & press ="
                    _display.value = "0"
                    isNewCalculation = true
                }
            } else {
                _instruction.value = "Enter matching 4-digit PIN!"
                _display.value = "0"
                isNewCalculation = true
            }
            return
        }

        // Ready state PIN matching
        if (state == PinState.READY && isFourDigits) {
            val savedPin = sharedPrefs.getString("PIN_CODE", "") ?: ""
            if (expr == savedPin) {
                _isVaultUnlocked.value = true
                _display.value = "0"
                isNewCalculation = true
                return
            }
        }

        // Otherwise evaluate standard math expression
        evaluateMathExpression(expr)
    }

    private fun evaluateMathExpression(expr: String) {
        try {
            val sanitized = expr.replace("×", "*").replace("÷", "/")
            val result = evaluate(sanitized)
            val df = DecimalFormat("#.#######")
            _display.value = df.format(result)
            isNewCalculation = true
        } catch (e: Exception) {
            _display.value = "Error"
            isNewCalculation = true
        }
    }

    private fun isOperator(c: Char): Boolean {
        return c == '+' || c == '-' || c == '×' || c == '÷' || c == '*' || c == '/'
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
        _display.value = "0"
        isNewCalculation = true
        checkPinStatus()
    }

    // Expression Parser logic
    private fun evaluate(expression: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < expression.length) expression[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < expression.length) throw RuntimeException("Unexpected character: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    if (eat('+'.code)) x += parseTerm() // addition
                    else if (eat('-'.code)) x -= parseTerm() // subtraction
                    else return x
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    if (eat('*'.code)) x *= parseFactor() // multiplication
                    else if (eat('/'.code)) {
                        val divisor = parseFactor()
                        if (divisor == 0.0) throw ArithmeticException("Division by zero")
                        x /= divisor // division
                    } else if (eat('%'.code)) {
                        x %= parseFactor() // modulo
                    } else return x
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.code)) return parseFactor() // unary plus
                if (eat('-'.code)) return -parseFactor() // unary minus

                var x: Double
                val startPos = pos
                if (eat('('.code)) { // parentheses
                    x = parseExpression()
                    eat(')'.code)
                } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) { // numbers
                    while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                    x = expression.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }

                return x
            }
        }.parse()
    }
}
